package com.company.model;


public class invoiceHeader {

    private int invoiceNumber;
    private String invoiceDate;
    private String customerName;

    public invoiceHeader(){
    }

    public invoiceHeader(int invoiceNumber, String invoiceDate, String customerName) {
        this.invoiceNumber = invoiceNumber;
        this.invoiceDate = invoiceDate;
        this.customerName = customerName;

    }

    public int getInvoiceNumber() {
        return invoiceNumber;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setInvoiceNumber(int invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate.replace("-","/");
    }

    @Override
    public String toString() {
        return "Invoice"+invoiceNumber+"Num"+"\n"+"{" +"\n"+ "Invoice"+invoiceNumber+"Date " + "("+invoiceDate +"), " + customerName;
    }
}
