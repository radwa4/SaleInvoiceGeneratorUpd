package com.company;

import com.company.view.displayInvoicesOnConsole;

public class Main {

    public static void main(String[] args) {

        displayInvoicesOnConsole print = new displayInvoicesOnConsole();
        print.printInvoicesOnConsole();
    }
}