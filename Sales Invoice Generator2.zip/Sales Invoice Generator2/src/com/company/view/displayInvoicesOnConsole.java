package com.company.view;

import com.company.controller.fileOperation;
import com.company.model.invoiceHeader;
import com.company.model.invoiceLine;

import java.util.List;

public class displayInvoicesOnConsole {

    public void printInvoicesOnConsole(){
        fileOperation file = new fileOperation();
        List<invoiceLine> invoiceLineArray = file.readInvoiceLinesFromCSV("src/com/company/resources/InvoiceLine.csv");
        List<invoiceHeader> invoiceHeaderArray = file.readInvoiceHeadersFromCSV("src/com/company/resources/InvoiceHeader.csv");

        for (int i = 0; i<invoiceHeaderArray.size();i++)
        {
            System.out.println(invoiceHeaderArray.get(i));
            for(int j = 0; j<invoiceLineArray.size();j++)
            {
                if (invoiceLineArray.get(j).getInvoiceNumber()==invoiceHeaderArray.get(i).getInvoiceNumber())
                {
                    System.out.println(invoiceLineArray.get(j));
                }
            }
            System.out.println("}");
        }
    }
}
